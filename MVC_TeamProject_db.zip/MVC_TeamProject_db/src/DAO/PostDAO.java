package DAO;

import Model.Post;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import static mvc_teamproject_db.MainMenu.currentRoute;
import static mvc_teamproject_db.MainMenu.currentUser;

public class PostDAO {
    
 Post post = new Post();
 Database db = new Database();
 ResultSet rs;
    
    public PostDAO(){
    
    }
    
    public ArrayList<Post> getAllPosts(){
        
        
        ArrayList<Post> arraylist= new ArrayList<>();
        
        try {
            rs = db.resultQuery("SELECT * FROM Posts");
            
            while(rs.next()){
                
                Post post = new Post();

                post.setId(rs.getInt("id"));
                post.setRout_id(rs.getInt("route_id"));
                post.setUser_id(rs.getInt("user_id"));
                post.setPost(rs.getString("post"));
                post.setCreated(rs.getString("created"));
                
                arraylist.add(post);
            }
            
        } catch (SQLException ex) {
            System.out.println("Something went wrong : " + ex.getMessage());
        }
    
    return arraylist;
    }
    
    public int createPost(Post post, Database db) throws SQLException{
        return db.resultUpdate("INSERT INTO `testdatabase`.`Posts` (`id`, `route_id`, `user_id`, `post`)"
                              + "VALUES ('" + post.getId() + "', '" + currentRoute.getId() + "', '" + currentUser.getId() + "','" + post.getPost() + "')");
    }
    
    public int deletePost(int id) throws SQLException{
        return db.resultUpdate("DELETE FROM Posts WHERE id ='" + id + "'");
    } 
    
    
    
}
    