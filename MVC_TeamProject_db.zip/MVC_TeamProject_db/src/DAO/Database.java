package DAO;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.sql.Statement;
import java.util.logging.Level;
import java.util.logging.Logger;


public class Database {
    
    protected String driver = "jdbc:mysql://188.166.121.77:3306/testdatabase";
    protected String username = "remoteuser";
    protected String password = "password321";
    
    
    Connection connection;
    ResultSet rs;
    PreparedStatement preStatement;
    Statement statement ;
    
    public Database(){
    
    }
    
    ResultSet resultQuery(String query) throws SQLException {
             
        connection = DriverManager.getConnection(driver, username, password );
        preStatement = connection.prepareStatement(query);
        rs = preStatement.executeQuery();
        return rs;
    }
         
         
    int resultUpdate(String query) throws SQLException {
                   
        connection = DriverManager.getConnection(driver, username, password );
        statement = connection.createStatement();
        int i = statement.executeUpdate(query);
         
        return i;    
    }
    
    public void closeConnection(){
        try {
            connection.close();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void closeResultset(){
        try {
            rs.close();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
    }
    
    public void closePreparedStatement(){
        try {
            preStatement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
    
    public void closeStatement(){
        try {
            statement.close();
        } catch (SQLException ex) {
            Logger.getLogger(Database.class.getName()).log(Level.SEVERE, null, ex);
        }
        
    }
     
    public void closeAll(){
    
        closeResultset();
        closePreparedStatement();
        closeStatement();
        closeConnection();
    
    }
    
}
