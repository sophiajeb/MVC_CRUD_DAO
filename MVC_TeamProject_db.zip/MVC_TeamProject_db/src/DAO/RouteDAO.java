package DAO;

import Model.Route;
import Model.Users;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;
import static mvc_teamproject_db.MainMenu.currentUser;


public class RouteDAO {
    
    public RouteDAO(){
    
    }   
    
    Route route = new Route();
    Database db = new Database();
    ResultSet rs;
    
    
    public ArrayList<Route> getAllRoutes(){
        
        
        ArrayList<Route> arraylist= new ArrayList<>();
        
        try {
            rs = db.resultQuery("SELECT * FROM Routes");
            
            while(rs.next()){
                
                Route route = new Route();

                route.setId(rs.getInt("id"));
                route.setCreator_id(rs.getInt("creator_id"));
                route.setTitle(rs.getString("title"));
                route.setSortdesc(rs.getString("shortdesc"));
                route.setDescription(rs.getString("description"));
                route.setSeats(rs.getInt("seats"));
                route.setDep_Time(rs.getString("dep_time"));
                route.setAr_time(rs.getString("ar_time"));

                arraylist.add(route);
            }
            
        } catch (SQLException ex) {
            System.out.println("Something went wrong : " + ex.getMessage());
        }
    
    return arraylist;
    }
    
    public int createRoute(Route route, Users user, Database db) throws SQLException{   
        return db.resultUpdate("INSERT INTO `testdatabase`.`Routes` (`id`, `creator_id`, `title`, `shortdesc`, `description`, `seats`, `dep_time`, `ar_time`)"
                              + "VALUES ('" + route.getId() + "', '" + currentUser.getId() + "', '" + route.getTitle() + "','" + route.getSortdesc() + "', '" + route.getDescription() + "', '" + route.getSeats() + "', '" + route.getDep_Time() + "', '" + route.getAr_time() + "')");
    }
    
    public int updateRoute(Route route, Database db) throws SQLException{
        return db.resultUpdate("UPDATE Routes SET title ='" + route.getTitle() + "', shortdesc='" + route.getSortdesc() + "', description='" + route.getDescription() + "' , seats='" + route.getSeats() + "', dep_time='" + route.getDep_Time() + "' , ar_time='" + route.getAr_time() + "' WHERE id ='" + route.getId() + "'");
    }   
    
    
    public int deleteRoute(int id) throws SQLException{
        return db.resultUpdate("DELETE FROM Routes WHERE id ='" + id + "'");
    } 
    
    public Route selectRouteForComment(int id){
        
        String query = "SELECT * FROM Routes WHERE id = '" + id + "'";
        
        try {
            rs = db.resultQuery(query);
                                 
            while(rs.next()){
                
                Route route = new Route();
                
                route.setId(rs.getInt("id"));
                route.setCreator_id(rs.getInt("creator_id"));
                route.setTitle(rs.getString("title"));
                route.setSortdesc(rs.getString("shortdesc"));
                route.setDescription(rs.getString("description"));
                route.setSeats(rs.getInt("seats"));
                route.setDep_Time(rs.getString("dep_time"));
                route.setAr_time(rs.getString("ar_time"));

                return route;
            }
            
        } catch (SQLException e) {
            System.out.println("Something went wrong: " + e.getMessage());
        }
     return null;
    }
    

    
    
}
