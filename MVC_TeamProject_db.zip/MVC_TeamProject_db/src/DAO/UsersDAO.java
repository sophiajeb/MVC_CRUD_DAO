package DAO;

import Model.Users;
import java.sql.ResultSet;
import java.sql.SQLException;
import java.util.ArrayList;

public class UsersDAO {
    
    
    Users user= new Users();
    Database db = new Database();
    ResultSet rs;
    
    public UsersDAO(){
    
    }
    
    public ArrayList<Users> getAllUsers(){
        
        ArrayList<Users> arraylist = new ArrayList<>();
        
        try {
            rs = db.resultQuery("SELECT * FROM Users");
                                 
            while(rs.next()){
                
                Users user= new Users();
                
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPass(rs.getString("password"));
                user.setFname(rs.getString("fname"));
                user.setLname(rs.getString("lname"));

                arraylist.add(user);
                
            }
            
        } catch (SQLException ex) {
            System.out.println("Something went wrong : " + ex.getMessage());
        }
    
    return arraylist;
    }
    
    public int createUser(String username, String password, String fname, String lname) throws SQLException{
        return db.resultUpdate("INSERT INTO `testdatabase`.`Users` (`username`, `password`, `fname`, `lname`)"
                              + "VALUES ('" + username + "', '" + password + "', '" + fname + "','" + lname + "')");
    }
    
    public int updateUser(String username, String password, String fname, String lname, int id) throws SQLException{
        return db.resultUpdate("UPDATE Users SET username='" + username + "', password='" + password + "', fname='" + fname + "', lname='" + lname
                + "' WHERE id ='" + id + "'");
    }   
    
    
    public int deleteUser(int id) throws SQLException{
        return db.resultUpdate("DELETE FROM Users WHERE id ='" + id + "'");
        
    }  
    
    public Users getUser(String username) {
        
        String query = "SELECT * FROM Users WHERE username = '" + username + "'";
        try {
            rs = db.resultQuery(query);
                                 
            while(rs.next()){
                
                Users user= new Users();
                
                user.setId(rs.getInt("id"));
                user.setUsername(rs.getString("username"));
                user.setPass(rs.getString("password"));
                user.setFname(rs.getString("fname"));
                user.setLname(rs.getString("lname"));

                return user;
            }
            
        } catch (SQLException e) {
            System.out.println("Something went wrong: " + e.getMessage());
        }
        return null;
    }
}
