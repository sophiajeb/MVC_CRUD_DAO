package mvc_teamproject_db;

import DAO.Database;
import Model.Post;
import Model.Route;
import Model.Users;
import Service.PostService;
import Service.RouteService;
import Service.UserService;
import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Scanner;


public class MainMenu {
    
    Database db = new Database();
    Users user = new Users();
    UserService userservice = new UserService();
    Route route = new Route();
    RouteService routeservice = new RouteService();
    
    Scanner input = new Scanner(System.in);
    Menu menu = new Menu();
    
    public static Users currentUser;
     
    public MainMenu(){
        
        System.out.println("Log In: ");
        System.out.println("Enter Username: ");
        String username = input.next();
        String password;
        Users finduser = userservice.getUser(username);
        if ( finduser == null){
            System.out.println("*** Username not exists ***");
            
        }else if (username.equals(finduser.getUsername())){
                 
            System.out.println("Enter Password: ");
            password = input.next();
                    
            if (password.equals(finduser.getPass())){
                currentUser=finduser;
                System.out.println("***Log in successful ***");
                        
                superAdminMenu();   
                
            }
        }
    }
        
//-----------------------------------------------------------------------------------------------------------------
         public void superAdminMenu() {
		
		menu.setTitle("*** Super Admin Menu ***");
                menu.addItem(new MenuItem("Show All Users", this, "getAllUsers"));
		menu.addItem(new MenuItem("Create User", this,"createUser"));
		menu.addItem(new MenuItem("Update User", this, "updateUser"));
                menu.addItem(new MenuItem("Delete User", this,"deleteUser"));
                menu.addItem(new MenuItem("Show All Routes", this,"getAllRoutes"));
                menu.addItem(new MenuItem("Create A new Route", this, "createRoute"));
                menu.addItem(new MenuItem("Update A Route", this, "updateRoute"));
                menu.addItem(new MenuItem("Delete Route", this,"deleteRoute"));
                menu.addItem(new MenuItem("Create Post", this,"selectRouteForComment"));
                menu.addItem(new MenuItem("Delete Post", this,"deletePost"));
                
		menu.execute();
    }
         
 //-------------------------------------------------------------------------------------------------------------
         
        public void createUser() throws SQLException {

            System.out.println("Create User: ");
            System.out.println("Enter Username: ");
            String username = input.next();
            System.out.println("Enter Password: ");
            String password = input.next();
            System.out.println("Enter first name: ");
            String fname = input.next();
            System.out.println("Enter last name: ");
            String lname = input.next();
     

            Users user = new Users();
            
            user.setUsername(username);
            user.setPass(password);
            user.setFname(fname);
            user.setLname(lname);
            
            UserService userservice = new UserService();

            userservice.createUser(user);
            System.out.println("*** User created ***");
    }
        
//-----------------------------------------------------------------------------------------------------------
    
    public void updateUser() throws SQLException {
            
        ArrayList<Users> arraylist = userservice.getAllUsers();

        for(Users u : arraylist) {
            System.out.println(u);
        }

            System.out.println("Update User Where id= ");
            int id=input.nextInt();
            System.out.println("Enter Username: ");
            String username = input.next();
            System.out.println("Enter Password: ");
            String password = input.next();
            System.out.println("Enter first name: ");
            String fname = input.next();
            System.out.println("Enter last name: ");
            String lname = input.next();
            
            Users user = new Users(id,username, password, fname, lname);
    
            userservice.updateUser(user);
            System.out.println("*** User updated ***");
    }
        
//-----------------------------------------------------------------------------------------------------------
        
    public void getAllUsers() {
          
        ArrayList<Users> arraylist = userservice.getAllUsers();
        System.out.println("*******************************************************");
        for(Users u : arraylist) {
            System.out.println("username: " + u.getUsername()+ ", password: " + u.getPass());
        }
            System.out.println("*******************************************************");

    }
//---------------------------------------------------------------------------------------------------------------- 
    
    public void deleteUser() throws SQLException {
               
        ArrayList<Users> arraylist = userservice.getAllUsers();
        System.out.println("*******************************************************");
            for(Users u : arraylist) {
                System.out.println(u);
            }
            
        System.out.println("Enter User id: ");
        int id = input.nextInt();

        int k = userservice.deleteUser(id);
        if(k==1){
            System.out.println("*** User Deleted ***");
        }
        else{ 
            System.out.println("*** User wasn't deleted ***");
        }
    }
           
//---------------------------------------------------------------------------------------------------------------
 
    public void createRoute() throws SQLException {

        System.out.println("Create Route: ");
        System.out.println("Enter Title: ");
        String title = input.next();
        System.out.println("Enter a Sort description: ");
        String sortdesc = input.next();
        System.out.println("Enter Description: ");
        String description = input.next();
        System.out.println("Enter seats: ");
        int seats = input.nextInt();
        System.out.println("Enter Dep. Time: ");
        String dep_Time = input.next();
        System.out.println("Enter Ar. Time: ");
        String ar_time = input.next();
          
        Route route = new Route();

        route.setTitle(title);
        route.setSortdesc(sortdesc);
        route.setDescription(description);
        route.setSeats(seats);
        route.setDep_Time(dep_Time);
        route.setAr_time(ar_time);
           
            
        RouteService routeservice= new RouteService();

        routeservice.createRoute(route, user, db);
        System.out.println("*** Route created ***");
    }
         
//---------------------------------------------------------------------------------------------
    public void updateRoute() throws SQLException {
            
        ArrayList<Route> arraylist = routeservice.getAllRoutes();

        for(Route route : arraylist) {
            System.out.println(route);
        }

            System.out.println("Update Route Where id= ");
            int id = input.nextInt();
            System.out.println("Enter Title: ");
            String title = input.next();
            System.out.println("Enter Sort Description: ");
            String sortdesc = input.next();
            System.out.println("Enter Description: ");
            String description = input.next();
            System.out.println("Enter Seats: ");
            int seats = input.nextInt();
            System.out.println("Enter Departure Time: ");
            String dep_time = input.next();
            System.out.println("Enter Arrival Time: ");
            String ar_time = input.next();
            
            Route route = new Route(id,currentUser.getId(),title,sortdesc,description,seats,dep_time,ar_time);
    
            routeservice.updateRoute(route, db);
            System.out.println("*** User updated ***");
    }
    
//---------------------------------------------------------------------------------------------
    public void getAllRoutes() {
          
        ArrayList<Route> arraylist = routeservice.getAllRoutes();
        System.out.println("*******************************************************");
        
        for(Route route: arraylist) {
            System.out.println("Id: " + route.getId() + " | Title: " + route.getTitle()+ " | Sort Description: " + route.getSortdesc());
        }
            System.out.println("*******************************************************");
    }
    
//---------------------------------------------------------------------------------------------
    
    public void deleteRoute() throws SQLException{
        ArrayList<Route> arraylist = routeservice.getAllRoutes();
        
        for(Route route : arraylist){
             System.out.println("Id: " + route.getId() + " | Title: " + route.getTitle()+ " | Sort Description: " + route.getSortdesc());
        }
    
        System.out.println("Delete Route Where id: ");
        int id =input.nextInt();
        
        int i = routeservice.deleteRoute(id);
            if(i==1){
                System.out.println("*** Route deleted ***");
            }
    
    }
    
//---------------------------------------------------------------------------------------------
    public static Route currentRoute;
    
    public void selectRouteForComment() throws SQLException{
        ArrayList<Route> arraylist = routeservice.getAllRoutes();
        
        for(Route route : arraylist){
             System.out.println("Id: " + route.getId() + " | Title: " + route.getTitle()+ " | Sort Description: " + route.getSortdesc());
        }
    
        System.out.println("Comment Route Where id: ");
        int id =input.nextInt();
        
        currentRoute = routeservice.selectRouteForComment(id);
        createPost();
    
    }
    
//---------------------------------------------------------------------------------------------
    public void createPost() throws SQLException {

        System.out.println("Create Post: ");
        System.out.println("Enter a Post: ");
        String comment = input.next();
        

        Post post = new Post();
        post.setPost(comment);
           
            
        PostService postservice = new PostService();
        postservice.createPost(post, db);

        System.out.println("*** Post created ***");
    }
    
//---------------------------------------------------------------------------------------------
    
    public void deletePost() throws SQLException{
        
        PostService postservice = new PostService();
        ArrayList<Post> arraylist =  postservice.getAllPosts();
        
        for(Post post : arraylist){
             System.out.println("Id: " + post.getId() + " | Post: " + post.getPost());
        }
    
        System.out.println("Delete Post Where id: ");
        int id =input.nextInt();

        int i = postservice.deletePost(id);
            if(i==1){
                System.out.println("*** Post deleted ***");
            }
    
    }
    
        
    
}

