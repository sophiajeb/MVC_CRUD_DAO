 package mvc_teamproject_db;


import DAO.Database;

import java.sql.SQLException;


public class MVC_TeamProject_db {

    
    public static void main(String[] args) throws SQLException {
        Database db = new Database();
        
        MainMenu mainmenu = new MainMenu();
        mainmenu.superAdminMenu();
        
    }
}
