package Model;


public class Route {
    public int id;
    public int creator_id;
    public String title;
    public String sortdesc;
    public String description;
    public int seats;
    public String dep_Time;
    public String ar_time;

    
    public Route(){
    
    }

    public Route(int id, int creator_id, String title, String sortdesc, String description, int seats, String dep_Time, String ar_time) {
        this.id = id;
        this.creator_id = creator_id;
        this.title = title;
        this.sortdesc = sortdesc;
        this.description= description;
        this.seats = seats;
        this.dep_Time = dep_Time;
        this.ar_time = ar_time;

        
    }


    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getCreator_id() {
        return creator_id;
    }

    public void setCreator_id(int creator_id) {
        this.creator_id = creator_id;
    }

    public String getTitle() {
        return title;
    }

    public void setTitle(String title) {
        this.title = title;
    }

    public String getSortdesc() {
        return sortdesc;
    }

    public void setSortdesc(String sortdesc) {
        this.sortdesc = sortdesc;
    }
    
    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public int getSeats() {
        return seats;
    }

    public void setSeats(int seats) {
        this.seats = seats;
    }

    public String getDep_Time() {
        return dep_Time;
    }

    public void setDep_Time(String dep_Time) {
        this.dep_Time = dep_Time;
    }

    public String getAr_time() {
        return ar_time;
    }

    public void setAr_time(String ar_time) {
        this.ar_time = ar_time;
    }



    @Override
    public String toString() {
        return "Route{" + "id=" + id + ", creator_id=" + creator_id + ", title=" + title + ", sortdesc=" + sortdesc + ", description=" + description + ", seats=" + seats + ", dep_Time=" + dep_Time + ", ar_time=" + ar_time + '}';
    }

   
   
    
}
