package Model;


public class Post {
    
    public int id;
    public int rout_id;
    public int user_id;
    public String post;
    public String created;
    
    public Post(){
    
    }

    public Post(int id, int rout_id, int user_id, String post, String created) {
        this.id = id;
        this.rout_id = rout_id;
        this.user_id = user_id;
        this.post = post;
        this.created = created;
    }

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public int getRout_id() {
        return rout_id;
    }

    public void setRout_id(int rout_id) {
        this.rout_id = rout_id;
    }

    public int getUser_id() {
        return user_id;
    }

    public void setUser_id(int user_id) {
        this.user_id = user_id;
    }

    public String getPost() {
        return post;
    }

    public void setPost(String post) {
        this.post = post;
    }

    public String getCreated() {
        return created;
    }

    public void setCreated(String created) {
        this.created = created;
    }

    @Override
    public String toString() {
        return "Post{" + "id=" + id + ", rout_id=" + rout_id + ", user_id=" + user_id + ", post=" + post + ", created=" + created + '}';
    }
    
    
    
}
