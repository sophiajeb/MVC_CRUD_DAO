package Service;

import DAO.Database;
import DAO.PostDAO;
import Model.Post;
import java.sql.SQLException;
import java.util.ArrayList;


public class PostService {
    PostDAO postdao=new PostDAO();
    Database db = new Database();
    
    public PostService(){
    
    }
    
    public ArrayList<Post> getAllPosts(){
        ArrayList<Post> postlist = new ArrayList(); 
        postlist= postdao.getAllPosts();
        
    return postlist;
    }
    
    public int createPost(Post post, Database db) throws SQLException{
        return postdao.createPost(post, db);
    }
    
    public int deletePost(int id) throws SQLException{
         return postdao.deletePost(id);
    }
    
    
    
}
