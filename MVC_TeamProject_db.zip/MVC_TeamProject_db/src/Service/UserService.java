package Service;

import DAO.Database;
import DAO.UsersDAO;
import Model.Users;
import java.sql.SQLException;
import java.util.ArrayList;

public class UserService {
    
    Database db = new Database();
    UsersDAO userdao = new UsersDAO();
    
    public UserService(){
    
    }
    
    public ArrayList<Users> getAllUsers(){
        ArrayList<Users> usersList = new ArrayList<>();
        usersList = userdao.getAllUsers();
        
        return usersList;
    }
    
    public int createUser(Users user) throws SQLException{
        return userdao.createUser(user.getUsername(), user.getPass(), user.getFname(), user.getLname());
    
    }
    
    public int updateUser(Users user) throws SQLException{
        return userdao.updateUser(user.getUsername(), user.getPass(), user.getFname(), user.getLname(), user.getId());
    }
    
    public int deleteUser(int id) throws SQLException{
        return userdao.deleteUser(id);
        
    }
    
    public Users getUser(String username){
    return userdao.getUser(username);
    }
    
}
