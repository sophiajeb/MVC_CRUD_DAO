package Service;

import DAO.Database;
import DAO.RouteDAO;
import Model.Route;
import Model.Users;
import java.sql.SQLException;
import java.util.ArrayList;


public class RouteService {
    
    RouteDAO routedao = new RouteDAO();
    Database db= new Database();
    
    public RouteService(){
    
    }
    
    public ArrayList<Route> getAllRoutes(){
        ArrayList<Route> routeList = new ArrayList<>();
        routeList = routedao.getAllRoutes();
        
        return routeList;
    }
    
    public int createRoute(Route route, Users user, Database db) throws SQLException{
        return routedao.createRoute(route, user , db);
    }
    
    public int updateRoute(Route route, Database db) throws SQLException{
        return routedao.updateRoute(route, db);
    }
    
    public int deleteRoute(int id) throws SQLException{
        return routedao.deleteRoute(id);
    }
    
    public Route selectRouteForComment(int id){
        return routedao.selectRouteForComment(id);
    }
}
